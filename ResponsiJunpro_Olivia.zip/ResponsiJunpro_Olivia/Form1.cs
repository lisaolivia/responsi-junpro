﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ResponsiJunpro_Olivia
{
    public partial class Form1 : Form
    {
        private string lastStatusMessage;     // contoh field private
        private string StatusMessage          // property public (encapsulation)
        {
            get { return lastStatusMessage; }
            set { lastStatusMessage = value; }
        }

        // Polymorphism - method overloading
        private void ShowStatus(string message)
        {
            MessageBox.Show(message);
        }

        private void ShowStatus(string message, string title)
        {
            MessageBox.Show(message, title);
        }

        string connString = "Host=localhost;Port=5432;Username=postgres;Password=informatika;Database=junpro_olivia;";

        public Form1()
        {
            InitializeComponent();
            try
            {
                LoadDepartemen();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading departemen: {ex.Message}\n\nPlease check your database connection.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        public void LoadData()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    string query = "SELECT * FROM kr_select()";

                    using (var da = new NpgsqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        dataGridView1.DataSource = null;  
                        dataGridView1.DataSource = dt;    
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading data: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void LoadDepartemen()
        {
            try
            {
                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    string query = "SELECT id_dep, nama_dep FROM departemen ORDER BY id_dep ASC";

                    using (var da = new NpgsqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        cmbDepartemen.DataSource = dt;
                        cmbDepartemen.DisplayMember = "nama_dep";
                        cmbDepartemen.ValueMember = "id_dep";
                    }
                }
            }
            catch (NpgsqlException ex)
            {
                throw new Exception($"Database connection error: {ex.Message}", ex);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error loading departemen: {ex.Message}", ex);
            }
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && dataGridView1.Rows[e.RowIndex].Cells.Count > 2)
                {
                    var row = dataGridView1.Rows[e.RowIndex];
                    txtID.Text = row.Cells[0].Value?.ToString() ?? "";
                    txtNama.Text = row.Cells[1].Value?.ToString() ?? "";
                    
                    if (row.Cells[2].Value != null)
                    {
                        cmbDepartemen.SelectedValue = row.Cells[2].Value.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error selecting row: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        private void btnLoad_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtNama.Text))
                {
                    MessageBox.Show("Nama karyawan tidak boleh kosong!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (cmbDepartemen.SelectedValue == null)
                {
                    MessageBox.Show("Pilih departemen terlebih dahulu!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    string query = $"SELECT kr_insert('{txtNama.Text.Replace("'", "''")}', '{cmbDepartemen.SelectedValue}')";

                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        int result = (int)cmd.ExecuteScalar();
                        if (result == 1)
                            ShowStatus("Data berhasil ditambahkan", "Insert");
                        else
                            ShowStatus("Gagal menambahkan data");
                    }
                }

                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error inserting data: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtID.Text))
                {
                    MessageBox.Show("Pilih data yang akan diupdate terlebih dahulu!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtNama.Text))
                {
                    MessageBox.Show("Nama karyawan tidak boleh kosong!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (cmbDepartemen.SelectedValue == null)
                {
                    MessageBox.Show("Pilih departemen terlebih dahulu!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    string query = $"SELECT kr_update('{txtID.Text}', '{txtNama.Text.Replace("'", "''")}', '{cmbDepartemen.SelectedValue}')";

                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        int result = (int)cmd.ExecuteScalar();
                        MessageBox.Show(result == 1 ? "Data berhasil diupdate" : "Gagal update");
                    }
                }

                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating data: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtID.Text))
                {
                    MessageBox.Show("Pilih data yang akan dihapus terlebih dahulu!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var confirmResult = MessageBox.Show("Apakah Anda yakin ingin menghapus data ini?", "Konfirmasi Hapus", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirmResult != DialogResult.Yes)
                    return;

                using (var conn = new NpgsqlConnection(connString))
                {
                    conn.Open();
                    string query = $"SELECT kr_delete('{txtID.Text}')";

                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        int result = (int)cmd.ExecuteScalar();
                        MessageBox.Show(result == 1 ? "Data terhapus" : "Gagal hapus");
                    }
                }

                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting data: {ex.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cmbDepartemen_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
