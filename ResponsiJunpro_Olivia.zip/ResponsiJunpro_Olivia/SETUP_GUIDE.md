# Complete Setup Guide - ResponsiJunpro_Olivia

## Part 1: Code Setup (Visual Studio / Development Environment)

### Prerequisites Check

**Step 1: Verify System Requirements**
- Windows 10 or later
- .NET Framework 4.7.2 or later installed
- Visual Studio 2017 or later (Community, Professional, or Enterprise)
  - OR Visual Studio Code with C# extension (for basic editing, but VS is recommended for Windows Forms)

**Step 2: Check if .NET Framework 4.7.2 is Installed**
1. Open File Explorer
2. Navigate to: `C:\Windows\Microsoft.NET\Framework\`
3. Look for folders like `v4.0.30319` (this indicates .NET Framework is installed)
4. Or check in Control Panel → Programs → Programs and Features → Look for "Microsoft .NET Framework 4.7.2" or higher

---

### Opening the Project

**Step 3: Open the Solution File**
1. Navigate to your project folder: `C:\Users\A S U S\Downloads\ResponsiJunpro_Olivia\ResponsiJunpro_Olivia`
2. Double-click on `ResponsiJunpro_Olivia.sln` file
   - This will open the project in Visual Studio
   - OR right-click → "Open with" → Visual Studio

**Alternative: If you don't have Visual Studio installed**
- Download Visual Studio Community (free) from: https://visualstudio.microsoft.com/
- During installation, make sure to select:
  - ✅ ".NET desktop development" workload
  - ✅ "Windows Forms App (.NET Framework)" component

---

### Restoring NuGet Packages

**Step 4: Restore NuGet Packages**
The project uses NuGet packages (especially Npgsql for PostgreSQL). You need to restore them:

**Option A: Using Visual Studio (Recommended)**
1. In Visual Studio, right-click on the solution in Solution Explorer
2. Click "Restore NuGet Packages"
3. Wait for the packages to download (this may take a few minutes)
4. Check the Output window for any errors

**Option B: Using Package Manager Console**
1. In Visual Studio, go to: Tools → NuGet Package Manager → Package Manager Console
2. Type: `Update-Package -reinstall`
3. Press Enter and wait for completion

**Option C: Using Command Line (if packages folder is missing)**
1. Open PowerShell or Command Prompt
2. Navigate to project folder:
   ```
   cd "C:\Users\A S U S\Downloads\ResponsiJunpro_Olivia\ResponsiJunpro_Olivia"
   ```
3. If you have NuGet.exe, run:
   ```
   nuget restore
   ```
   OR if you have MSBuild:
   ```
   msbuild /t:Restore
   ```

**Step 5: Verify Packages are Restored**
- Check that the `packages` folder exists in your project directory
- It should contain folders like:
  - `Npgsql.7.0.6`
  - `Microsoft.Bcl.AsyncInterfaces.7.0.0`
  - `System.Buffers.4.5.1`
  - etc.

---

### Building the Project

**Step 6: Build the Solution**
1. In Visual Studio, go to: Build → Build Solution (or press `Ctrl+Shift+B`)
2. Check the Output window at the bottom
3. Look for: `========== Build: 1 succeeded, 0 failed, 0 up-to-date, 0 skipped ==========`

**If Build Fails:**
- Check the Error List window (View → Error List)
- Common issues:
  - Missing NuGet packages → Repeat Step 4
  - Wrong .NET Framework version → Check project properties
  - Missing references → Right-click References → Restore NuGet Packages

**Step 7: Fix Any Build Errors**
- Read error messages carefully
- Most common fix: Right-click solution → Restore NuGet Packages → Rebuild

---

### Running the Application

**Step 8: Run Without Debugging (Quick Test)**
1. Press `Ctrl+F5` (or Debug → Start Without Debugging)
2. The form should open (even if database connection fails, it will show a warning)

**Step 9: Run With Debugging (Recommended for Development)**
1. Press `F5` (or Debug → Start Debugging)
2. The form will open and you can set breakpoints to debug

**Step 10: Verify the Form Opens**
- You should see a Windows Form with:
  - Text boxes for Nama Karyawan
  - Combo box for Departemen
  - Buttons: Insert, Update, Delete, Load
  - Data Grid View at the bottom
- If database is not connected, you'll see a warning message (this is expected)

---

### Troubleshooting Common Code Issues

**Issue: "The type or namespace name 'Npgsql' could not be found"**
- **Solution**: Restore NuGet packages (Step 4)

**Issue: "Could not load file or assembly 'Npgsql.dll'"**
- **Solution**: 
  1. Delete `bin` and `obj` folders
  2. Rebuild the solution
  3. Restore NuGet packages again

**Issue: "The project file cannot be opened"**
- **Solution**: 
  1. Make sure you're using Visual Studio 2017 or later
  2. Try opening the `.csproj` file directly instead of `.sln`

**Issue: Form doesn't appear when running**
- **Solution**: 
  1. Check `Program.cs` - make sure `Application.Run(new Form1());` is present
  2. Check if there are any unhandled exceptions in the constructor
  3. Run with debugging (F5) to see error messages

---

### Project Structure Overview

```
ResponsiJunpro_Olivia/
├── Form1.cs              ← Main form logic (database operations)
├── Form1.Designer.cs     ← Form design (UI layout)
├── Form1.resx            ← Form resources
├── Program.cs            ← Application entry point
├── ResponsiJunpro_Olivia.csproj  ← Project file
├── ResponsiJunpro_Olivia.sln      ← Solution file
├── packages/             ← NuGet packages (after restore)
├── bin/                  ← Compiled executable (after build)
└── obj/                  ← Build artifacts
```

---

### Quick Verification Checklist

Before moving to database setup, verify:
- ✅ Project opens in Visual Studio without errors
- ✅ NuGet packages are restored (packages folder exists)
- ✅ Solution builds successfully (no errors in Error List)
- ✅ Form opens when you run the application (F5 or Ctrl+F5)
- ✅ You see the form UI (even if database connection fails)

---

## Next Steps

Once the code is running successfully, proceed to **Part 2: Database Setup** (which will be provided next).

The application expects:
- PostgreSQL database server running
- Database name: `junpro_olivia`
- Username: `postgres`
- Password: `informatika`
- Tables: `departemen` and `karyawan`
- Functions: `kr_select()`, `kr_insert()`, `kr_update()`, `kr_delete()`