# ResponsiJunpro_Olivia - Windows Forms Application

A Windows Forms application for managing employee (karyawan) data with PostgreSQL database integration.

## 📁 Project Structure

```
ResponsiJunpro_Olivia/
├── Form1.cs                    # Main form with database operations
├── Form1.Designer.cs           # Form UI design
├── Program.cs                  # Application entry point
├── ResponsiJunpro_Olivia.csproj  # Project configuration
├── ResponsiJunpro_Olivia.sln     # Solution file
└── packages/                   # NuGet packages (Npgsql, etc.)
```

## 🚀 Quick Start

### For First-Time Setup:
1. **Read**: `SETUP_GUIDE.md` - Complete detailed guide
2. **Use**: `QUICK_START_CHECKLIST.md` - Quick reference

### Quick Steps:
1. Open `ResponsiJunpro_Olivia.sln` in Visual Studio
2. Restore NuGet Packages (Right-click Solution → Restore NuGet Packages)
3. Build (Ctrl+Shift+B)
4. Run (F5)

## 📋 Features

- ✅ CRUD operations (Create, Read, Update, Delete) for employees
- ✅ Department selection via ComboBox
- ✅ Data display in DataGridView
- ✅ Error handling and validation
- ✅ PostgreSQL database integration

## 🛠️ Technology Stack

- **Framework**: .NET Framework 4.7.2
- **UI**: Windows Forms
- **Database**: PostgreSQL
- **ORM/Driver**: Npgsql 7.0.6

## 📝 Database Requirements

- PostgreSQL Server
- Database: `junpro_olivia`
- Username: `postgres`
- Password: `informatika`
- Required tables: `departemen`, `karyawan`
- Required functions: `kr_select()`, `kr_insert()`, `kr_update()`, `kr_delete()`

## 🔧 Configuration

Database connection string is in `Form1.cs`:
```csharp
string connString = "Host=localhost;Port=5432;Username=postgres;Password=informatika;Database=junpro_olivia;";
```

## 📚 Documentation

- **SETUP_GUIDE.md** - Complete step-by-step setup instructions
- **QUICK_START_CHECKLIST.md** - Quick reference checklist

## ⚠️ Notes

- The application will show a warning if the database is not connected, but the form will still open
- All database operations include error handling
- Input validation is implemented for all fields

## 🐛 Troubleshooting

See `SETUP_GUIDE.md` for detailed troubleshooting steps.

Common issues:
- Missing NuGet packages → Restore NuGet Packages
- Build errors → Delete `bin` and `obj` folders, rebuild
- Database connection → Check PostgreSQL is running and credentials are correct

